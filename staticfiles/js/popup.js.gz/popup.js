function openPopup(){
           
            /*popup.classList.add("open-popup");*/
           alert('Merci de souscrire! Vous recevrai desormais nos newsletter!');
        }
        function closePopup(){
            popup.classList.remove("open-popup")
        }
